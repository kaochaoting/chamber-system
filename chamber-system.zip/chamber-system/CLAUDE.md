# CLAUDE.md — Claude Code 開工指揮

> 這個 repo 含**完整規劃（docs/）＋ MVP 骨幹程式（src/、根設定、scripts/）**。
> 你的任務：把它整合成一個能在本機跑起來的 SvelteKit + Cloudflare 商會系統，並完成 MVP。
> 全程以**正體中文（zh-TW）**撰寫 UI 文案、commit 訊息與回報。

## 專案一句話

勞工大學創新創業專班的雙層商會系統：**對內封閉信任 × 對外開放索引**。
品牌北極星：不只讓人看見你，而是讓人選擇你。

## 權威規格（先讀，依序）

1. `docs/PRD.md` — 要做什麼、為誰、成功指標、已拍板決策
2. `docs/SSD.md` — 架構、資料模型、路由、API、安全、部署、已知風險
3. `docs/DESIGN_SYSTEM.md` — 色彩／字體／元件（tokens 已在 `src/lib/styles/tokens.css`）
4. `docs/BUILD_MANIFEST.md` — 逐檔開工清單與里程碑 M0–M6
5. `docs/README.md` — ADR 決策日誌（Workers、Better Auth 等決策理由）

`src/`、`wrangler.jsonc`、`svelte.config.js`、`drizzle.config.ts`、`scripts/` 是**已寫好的起點**，請整合沿用，不要從零重寫。

## 技術棧（已定案，見 ADR）

SvelteKit（Svelte 5）+ `@sveltejs/adapter-cloudflare`（部署 Workers）+ Drizzle ORM + Cloudflare D1/R2/KV + Better Auth（Email/密碼 + Google）。

## 一次完成的步驟

1. **Scaffold**：在本 repo 用官方 CLI 建立 SvelteKit（TypeScript、Svelte 5），安裝相依：
   `@sveltejs/adapter-cloudflare wrangler @cloudflare/workers-types drizzle-kit drizzle-orm better-auth`。
2. **覆蓋**：用本 repo 既有的 `wrangler.jsonc` / `svelte.config.js` / `drizzle.config.ts` / `src/` / `scripts/` 覆蓋 scaffold 產物。
3. **對齊 Better Auth schema（最高風險，先做）**：執行 `npx @better-auth/cli generate`，比對並修正 `src/lib/server/db/schema.ts` 的 `user/session/account/verification` 四表至一致；保留 `role/status/cohort` 自訂欄位。
4. **資料庫**：建本機 D1，`drizzle-kit generate` 產 migration，`wrangler d1 migrations apply chamber-db --local` 套用，再套 `scripts/seed.sql`。
5. **驗證核心**（M2 必過）：`wrangler dev` 起本機，實測三條路：
   - 邀請碼 `KLU-115-WELCOME` 註冊 → 直接登入進 `/app`
   - 不帶碼註冊 → 落在 `/pending`
   - Google 登入新帳號 → 落在 `/pending`（需先填 `.dev.vars` 的 Google 憑證；若未設定，先跳過 Google 驗證）
6. **補完 MVP**：依 `docs/BUILD_MANIFEST.md` 完成 M3–M6（個人資料圖片上傳、對外名錄/成員頁、消息/部落格、後台審核），未盡之 V1（創業/產品、論壇、互通有無）依相同模式建立骨架。
7. **Git**：以邏輯分段 commit；完成後用 `gh repo create` 建立 GitHub repo 並 push。

## 鐵則 / Watch-points

- **Better Auth + D1 + Workers**：db 由 `platform.env.DB` 請求內注入；adapter `provider:'sqlite'`；`sveltekitCookies` 置 plugins 最後。
- **Google ≠ 繞過閘門**：新帳號預設 `pending`；email + 邀請碼路徑才自動 `active`。
- **可見性於查詢階段過濾**，不要查出再隱藏。
- **私密路由** `/app`、`/admin` 一律 `noindex`；對外頁輸出 JSON-LD。
- **機密絕不入庫**：用 `.dev.vars`（本機）與 `wrangler secret put`（正式）；`.env.example` 為樣板。
- **設計**：色彩字體一律引用 `tokens.css` 變數，不硬編。
- **語言**：UI 文案正體中文；`app.html` 已鎖 `lang="zh-Hant"`。

## 完成定義（DoD）

- `wrangler dev` 可起，上述三條註冊/登入路徑行為正確。
- 對外頁（首頁、`/members`、`/members/[slug]`）可 `curl` 取得且含 Schema；私密頁未登入導向 `/login`。
- 對應 `docs/BUILD_MANIFEST.md` 的 M0–M6 完成；過程中的取捨補進 `docs/adr/`。
- 卡關或版本不一致：直接修，並在回報中說明改了什麼。
