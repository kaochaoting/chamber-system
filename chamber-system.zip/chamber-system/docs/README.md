# 文件索引與治理（Docs Index & Governance）

本資料夾是商會系統的**單一事實來源（single source of truth）**。所有產品與技術決策以此為準；程式碼若與文件不符，以最新版文件為準並補開 issue。

## 文件地圖

| 文件 | 角色 | 回答的問題 |
|---|---|---|
| [`PRD.md`](./PRD.md) | 產品需求 | 要做什麼？為誰做？為什麼？成功長什麼樣？ |
| [`SSD.md`](./SSD.md) | 系統設計 | 怎麼實作？架構、資料、API、安全、部署。 |
| [`DESIGN_SYSTEM.md`](./DESIGN_SYSTEM.md) | 設計系統 | 長什麼樣？色彩、字體、元件、可及性。 |
| [`adr/`](./adr/) | 決策記錄 | 為什麼這樣選？每個重大決策一筆。 |

## 版本治理

- 每份文件頂端維護 `狀態 / 版本 / 最後更新` 三欄。
- 狀態流：`草稿(Draft)` → `審閱中(Review)` → `已定案(Approved)` → `已棄用(Deprecated)`。
- 文件變更走 Pull Request，至少一位 reviewer。重大變更需同步新增一筆 ADR。

## ADR 機制（逐步完善的核心）

ADR（Architecture Decision Record）讓系統能演進而不遺失脈絡。規則：

1. 每個**有取捨**的決策建一個檔：`adr/NNNN-簡短標題.md`（編號遞增、永不重用）。
2. 格式固定四段：**背景 → 決策 → 後果 → 替代方案**。
3. ADR 一旦定案就**不修改**；要推翻，新增一筆並把舊的標為 `Superseded by ADR-NNNN`。

---

## 決策日誌（ADR Log）

> 下方為種子 ADR，正式開 repo 後請各自拆成 `adr/0001-*.md`、`adr/0002-*.md`。

### ADR-0001：部署目標採 Cloudflare Workers（而非 Pages）

- **狀態**：已定案
- **背景**：原始需求指定 Cloudflare Pages。但 2026 現況為 Cloudflare 正將 Pages 收斂進 Workers，Workers 已具靜態資產／SSR／自訂網域對等能力，新功能優先上 Workers，Pages 進入維護狀態。
- **決策**：以 **Workers** 為部署標的；SvelteKit 端統一使用 `@sveltejs/adapter-cloudflare`（同時支援 Workers 與 Pages，寫法一致）。
- **後果**：可用 D1／R2／KV／Queues 全平台能力；自訂網域需 Cloudflare 託管 nameserver（本專案網域已在 Cloudflare，前提滿足）。日後若需退回 Pages，僅換部署設定。
- **替代方案**：續用 Pages（功能落後、長期維護風險）；改用 Vercel/Netlify（脫離既有 Cloudflare 網域與生態）。

### ADR-0002：驗證採 Better Auth（而非 Lucia）

- **狀態**：已定案
- **背景**：Lucia 已於 2024 年停止維護，現僅為「自行實作 session」的教學參考，非可安裝套件。
- **決策**：採 **Better Auth + Drizzle adapter**，資料庫 provider 設 `sqlite` 指向 D1。
- **後果**：取得型別化 auth client、session 管理、密碼雜湊、自動產生資料表。需驗證「Better Auth + D1 + Workers」整合（db 由 `platform.env` 注入；`sveltekitCookies` plugin 置於陣列最後）。
- **替代方案**：自行以 Oslo/Arctic 刻 session（控制權高但程式碼負擔重）；Auth0/Clerk（資料外託、不符資料自主原則）。

### ADR 待補（後續決策請依序新增）

- 0003：ORM 選型（建議 Drizzle，理由：型別安全、D1 原生支援、migration 工具）
- 0004：圖片儲存與轉檔（R2 + Cloudflare Images vs 自管縮圖）
- 0005：是否導入 i18n（影響路由結構，建議 MVP 後再評估）
