# SSD｜商會系統系統設計文件

| 狀態 | 版本 | 最後更新 |
|---|---|---|
| 草稿(Draft) | 0.1.0 | 待填 |

> 本文件吸收並取代先前的「架構設計規格書」，作為 repo 內技術設計的單一事實來源。

---

## 1. 架構總覽

```
[瀏覽器] ──HTTPS（Cloudflare 邊緣）──▶ [SvelteKit on Cloudflare Workers]
                                           │  adapter: @sveltejs/adapter-cloudflare
                                           ├── D1 (SQLite)  業務關聯資料
                                           ├── R2           圖片（存 object key）
                                           └── KV (選用)     session 快取 / rate limit / 名錄快取
```

- 對外路徑：可索引、可快取、結構化資料豐富。
- 對內路徑：需登入、`noindex`、RBAC 守門。
- 兩者共用同一個 Worker，但以路由前綴與標頭策略分流。

## 2. 技術棧與理由

| 層 | 選型 | 理由（詳見 ADR） |
|---|---|---|
| 框架 | SvelteKit | 指定；SSR + 檔案式路由 + form actions 適合此類應用 |
| 部署 | Cloudflare Workers | ADR-0001 |
| Adapter | `@sveltejs/adapter-cloudflare` | 同時支援 Workers/Pages |
| DB | Cloudflare D1 (SQLite) | 邊緣原生、零維運 |
| ORM | Drizzle | 型別安全、D1 原生、migration 工具 |
| 驗證 | Better Auth | ADR-0002 |
| 物件儲存 | R2 | 圖片；資料庫只存 key |
| 快取 | KV（選用） | session/熱資料 |

## 3. 資料模型

> 認證表（`user`/`session`/`account`/`verification`）由 Better Auth 產生。以下為業務表，以 `user.id` 外鍵串接。

| 表 | 主要欄位 | 說明 |
|---|---|---|
| `profiles` | `user_id`(FK,PK), `slug`, `display_name`, `avatar_key`, `bio`, `cohort`, `role`, `public_contact`(json), `private_contact`(json), `socials`(json), `is_public` | 公開／私密聯絡分欄 |
| `ventures` | `id`, `user_id`(FK), `name`, `tagline`, `description`, `logo_key`, `industry_id`(FK), `website_url`, `status`, `is_public` | `website_url`＝對外導出回鏈 |
| `products` | `id`, `venture_id`(FK), `kind`(product/service), `name`, `description`, `price_label`, `image_keys`(json), `external_url`, `is_public` | |
| `posts` | `id`, `author_id`(FK), `type`(news/article/thread), `title`, `slug`, `body`, `category_id`, `visibility`(public/members), `status`(draft/published), `pinned`, `created_at` | 消息/部落格/論壇共用 |
| `comments` | `id`, `post_id`(FK), `author_id`(FK), `body`, `created_at` | |
| `board_items` | `id`, `user_id`(FK), `kind`(offer/need), `title`, `description`, `contact`, `status`(open/closed) | 互通有無 |
| `industries` | `id`, `name`, `slug` | 型錄篩選 |
| `categories` | `id`, `name`, `slug` | 文章分類 |
| `invites` | `code`(PK), `cohort`, `created_by`, `used_by`, `expires_at` | 封閉註冊 |
| `audit_logs` | `id`, `actor_id`, `action`, `target`, `created_at` | 治理軌跡 |

**索引建議**：`profiles.slug`、`posts.slug`、`posts(visibility,status)`、`ventures(industry_id,is_public)`、`board_items(kind,status)`。

## 4. 路由與 API 契約

### 4.1 頁面路由

| 區 | 路由 | 渲染 | 索引 |
|---|---|---|---|
| 對外 | `/`,`/about`,`/members`,`/members/[slug]`,`/directory`,`/news`,`/news/[slug]` | SSR/prerender | ✅ |
| 驗證 | `/login`,`/register`,`/logout` | SSR | noindex |
| 對內 | `/app`,`/app/profile`,`/app/ventures`,`/app/directory`,`/app/forum`,`/app/forum/[slug]`,`/app/board`,`/app/resources` | SSR | noindex |
| 後台 | `/admin/**` | SSR | noindex |

### 4.2 伺服器端點與 form actions（範例契約）

| 操作 | 機制 | 權限 |
|---|---|---|
| 申請加入 | action `POST /register` | guest |
| 登入/登出 | Better Auth `/api/auth/*` | guest/self |
| 更新個人資料 | action `POST /app/profile` | self(member+) |
| 建立/編輯創業/產品 | action `/app/ventures` | owner |
| 發文/留言 | action `/app/forum/*` | member+ |
| 發消息 | action `/admin` or `/app`（依角色） | mentor/admin |
| 審核會員/指派角色 | action `/admin` | assistant/admin |
| 圖片上傳 | `POST /api/upload` → R2，回傳 key | member+ |
| 取圖 | `GET /img/[key]` | 依內容可見性 |

> 一律使用 SvelteKit form actions + 漸進增強；避免裸 fetch 端點，降低 CSRF 面（SvelteKit 內建 CSRF 保護需保持啟用）。

## 5. 驗證與授權設計

- **AuthN**：Better Auth（email/密碼，選用 Google）。session 以 cookie 管理。
- **守門**：`hooks.server.ts` 解析 session → `event.locals.user`（含 role/status）→ 對 `/app/**`、`/admin/**` 設 `X-Robots-Tag: noindex`。
- **AuthZ**：每條私密路由 `load` 內伺服器端再驗（role + status === active）；內容查詢階段即以 `visibility` 過濾，不查出再隱藏。
- **角色矩陣**：見 PRD §3 與下方序列流。

## 6. 關鍵序列流（文字版）

**註冊→啟用（兩條路徑＋Google）**
```
A. 邀請碼路徑：提交(含有效 invite code) → 建 user(status=active, role=member, cohort=碼帶入)
B. 申請路徑：  提交(無碼,表單)         → 建 user(status=pending) → admin/助教 審核 → active
Google 登入：  作為驗證方式，非授權捷徑
   - 既有 active 帳號 → 直接登入
   - 新帳號 → 預設 status=pending（除非循邀請連結帶入 code，則 active）
   - 以 Better Auth databaseHooks(user.create) 寫入 role/status/cohort
```

**登入＋守門**
```
使用者 提交登入 → Better Auth 驗證 → 設 session cookie
  → hooks 解析 → locals.user 寫入
  → 進入 /app/* 時 load 檢查 role/status → 不符則 302 → /login
```

**發佈公開文章（含 SEO）**
```
mentor/admin 撰寫(草稿) → 發佈(status=published, visibility=public)
  → 生成語意 slug → 進入 sitemap → 公開頁輸出 Article JSON-LD
```

**對外瀏覽（信任外溢）**
```
訪客 → /members/[slug] → 載入公開 profile+ventures+products
  → 輸出 Person/Organization/Product Schema
  → 點擊 website_url → 導往成員官網(rel 正常 follow，傳遞背書)
```

## 7. 非功能需求（NFR）

- **效能**：公開頁 Lighthouse ≥ 90；盡量 prerender/快取；圖片走 R2 + 尺寸轉換。
- **安全**：所有輸入伺服器端驗證；圖片上傳限制類型/大小；機密走 Wrangler secrets（不入庫不入 git）；保留 SvelteKit CSRF 保護；對 `/register`、登入做 rate limit（KV）。
- **SEO**：公開頁可索引 + JSON-LD + sitemap；私密頁全面 noindex 且不入 sitemap。
- **可及性**：WCAG AA（見 DESIGN_SYSTEM）。
- **可移植/開源**：環境綁定集中於 `wrangler.jsonc` 與 `.env.example`；不硬編敏感值。
- **i18n-ready**：文案集中管理，預留語系切換（MVP 單語）。

## 8. 部署與 CI/CD

- **本機**：`wrangler` v4；bindings 由 `platformProxy` 在 dev/preview 模擬。adapter 產出於 `.svelte-kit/cloudflare/`（勿用 `dist/`）。
- **wrangler.jsonc**：`compatibility_flags: ["nodejs_compat"]`、D1/R2/KV 綁定、`main: .svelte-kit/cloudflare/_worker.js`、`assets.directory: .svelte-kit/cloudflare`。
- **CI（GitHub Actions）**：PR → lint + build + 預覽部署；merge to main → `wrangler deploy` 正式環境。secrets 存 GitHub Encrypted Secrets（`CLOUDFLARE_API_TOKEN` 等）。
- **DB migration**：Drizzle 產生 SQL → 以 wrangler 對 D1 套用；migration 檔納入版控。

## 9. 可觀測性

- Cloudflare 後台監看 Requests/CPU time（免費級 10 萬 req/日）。
- `audit_logs` 表記錄後台操作。
- 錯誤回報：先以結構化 console（Workers logs）為主，後續可接 Tail Worker。

## 10. 已知技術風險

1. **Better Auth + D1 + Workers 整合**【需 CODEX 優先驗證】：db 由 `platform.env.DB` 注入；Drizzle adapter `provider: 'sqlite'`；`sveltekitCookies` plugin 置於陣列最後。先以最小登入流程跑通再擴充。
2. **Worker 體積上限**：避免大型套件進 server bundle，必要時僅 client 端引入。
3. **自訂網域**：Workers 自訂網域需 Cloudflare 託管 nameserver（已滿足）。
