# BUILD MANIFEST｜CODEX 逐檔開工清單

| 狀態 | 版本 | 最後更新 |
|---|---|---|
| 草稿(Draft) | 0.1.0 | 待填 |

> 本文件把 SSD 收斂成可逐檔執行的任務。依里程碑順序開工；每項含**用途／輸入／輸出／完成定義(DoD)**。
> 已鎖定決策：①邀請碼+申請審核並存 ②啟用 Google 登入（過閘門）③中文 only ④論壇/部落格共表。

---

## 開工總則

- 技術棧：SvelteKit + `@sveltejs/adapter-cloudflare`（部署 Workers）+ Drizzle + Better Auth + D1/R2/KV。
- 順序鐵則：**M2 驗證最先打通**（唯一高風險整合），再往上疊功能。
- 每個里程碑結束＝可部署、可驗收。每完成一個有取捨的決策補一筆 ADR。
- 機密一律走 Wrangler secrets / `.dev.vars`，**不入 git**；提供 `.env.example`。

---

## M0 — 專案骨架與基礎設施

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `package.json` | 依賴與腳本 | — | dev/build/deploy/db scripts | `npm run dev` 可起 |
| `svelte.config.js` | 指定 adapter-cloudflare | — | adapter 設定 | build 產出於 `.svelte-kit/cloudflare/` |
| `wrangler.jsonc` | Workers 設定與綁定 | — | `nodejs_compat`、DB/BUCKET/KV 綁定、assets 路徑 | `wrangler dev` 可起、綁定可見 |
| `drizzle.config.ts` | Drizzle 設定 | — | schema 路徑、D1 dialect | `drizzle-kit generate` 可跑 |
| `.env.example` / `.dev.vars` | 機密樣板/本機 | — | `BETTER_AUTH_SECRET`,`GOOGLE_CLIENT_ID/SECRET` 等 | 本機讀得到、git 忽略真值 |
| `src/app.html` | HTML 殼 | — | `<html lang="zh-Hant">` | 語言鎖定中文 |
| `src/app.d.ts` | 型別 | — | `App.Locals{user,session}`、`App.Platform{env:{DB,BUCKET,KV}}` | 型別檢查通過 |
| `src/lib/styles/tokens.css` | 設計 tokens | DESIGN_SYSTEM | `:root` 與 `[data-theme=dark]` 變數 | 元件僅引用變數、無硬編色值 |

## M1 — 資料層

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/lib/server/db/schema.ts` | Drizzle schema | SSD §3 | 全業務表＋索引 | `generate` 產出 migration |
| `src/lib/server/db/client.ts` | DB 連線 | `platform.env.DB` | `drizzle(DB)` 實例（請求內注入，非全域） | load/action 可查詢 |
| `migrations/*.sql` | 結構遷移 | schema | SQL | 對 D1 套用成功 |
| `scripts/seed.ts` | 種子資料 | — | 1 admin、3 demo 成員、產業/分類、1 邀請碼 | 套用後可登入 demo |

## M2 — 驗證與閘門（最高優先，先打通）

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/lib/server/auth.ts` | Better Auth 設定 | D1、Google 憑證 | email/密碼 + Google provider；`databaseHooks.user.create` 寫入 `role=member`、`status`、`cohort`；`sveltekitCookies` **置陣列最後** | 建立帳號自動帶預設欄位 |
| `src/routes/api/auth/[...all]/+server.ts` | Better Auth handler | request | `/api/auth/*` 路由 | 登入/登出/Google 流程通 |
| `src/lib/server/rbac.ts` | 授權守衛 | `locals.user` | `requireActive()`,`requireRole(...)` | 不符回 302/403 |
| `src/lib/server/invites.ts` | 邀請碼驗證 | code | 有效則回 cohort、標記 used | 有效碼→active；無效/過期→拒 |
| `src/hooks.server.ts` | 全域守門 | request | 解析 session→`locals`；`/app`,`/admin` 設 `X-Robots-Tag:noindex`＋守門 | 未登入進 /app 必 302 |
| `src/routes/register/+page.svelte` `+page.server.ts` | 申請加入 | 表單(可含 code) | action：有碼→active；無碼→pending | 兩路徑各自正確落狀態 |
| `src/routes/login/+page.svelte` `+page.server.ts` | 登入 | email/密碼、Google 按鈕 | session | 成功進 /app |
| `src/routes/logout/+page.server.ts` | 登出 | — | 清 session | 回首頁 |

> **閘門規則（務必）**：Google 新帳號預設 `pending`，除非循邀請連結帶入 code 才 `active`。Google 不得繞過封閉性。
> **M2 驗收**：完整跑通「邀請碼註冊→直接進 /app」「無碼申請→pending→被擋→admin 核准→可進」「Google 新帳號→pending」三條路。

## M3 — 個人資料

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/routes/(app)/app/profile/+page.svelte` `+page.server.ts` | 編輯個人資料 | 表單 | 公開/私密欄位分流寫入 `profiles` | 私密欄不出現在公開頁 |
| `src/routes/api/upload/+server.ts` | 圖片上傳 | file | 存 R2，回 key | 限類型/大小；回傳 key |
| `src/routes/img/[key]/+server.ts` | 取圖 | key | R2 物件 | 依可見性授權 |
| `src/lib/components/Avatar.svelte` | 頭像 | key | 圖 | 缺圖有預設 |

## M4 — 對外展示（可索引）

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/routes/+page.svelte` `+page.server.ts` | 首頁 | 精選成員/消息 | SSR | Lighthouse≥90 |
| `src/routes/members/+page.svelte` `+page.server.ts` | 公開名錄 | `is_public` 成員 | 列表+產業篩選 | 僅顯示公開者 |
| `src/routes/members/[slug]/+page.svelte` `+page.server.ts` | 公開成員頁 | slug | profile+venture+Schema | 輸出 Person/Organization JSON-LD；含官網外鏈 |
| `src/lib/server/seo.ts` | Schema/SEO 工具 | 實體 | JSON-LD 產生器 | 結構化資料驗證通過 |
| `src/routes/sitemap.xml/+server.ts` | sitemap | 公開頁 | XML | 只含公開、不含私密 |
| `src/routes/robots.txt/+server.ts` | robots | — | txt | 私密路由 disallow |
| `src/lib/components/MemberCard.svelte` `TrustSeal.svelte` `Chip.svelte` | 展示元件 | props | UI | 含信任印章簽名元素 |

## M5 — 消息／部落格（共表）

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/routes/news/+page.svelte` `+page.server.ts` | 公開消息列表 | `posts(type in news/article, visibility=public, published)` | 列表 | 只列公開已發佈 |
| `src/routes/news/[slug]/+page.svelte` `+page.server.ts` | 單篇 | slug | 內文+Article Schema | JSON-LD 通過 |
| 後台發佈（見 M6） | mentor/admin 發消息 | — | 草稿/發佈 | 角色限定 |

## M6 — 後台治理（MVP 收尾）

| 檔案 | 用途 | 輸入 | 輸出 | DoD |
|---|---|---|---|---|
| `src/routes/(admin)/admin/+layout.server.ts` | 後台守門 | `locals.user` | 限 assistant/admin | 他人 403 |
| `.../admin/members/+page` | 審核佇列/角色 | pending 清單 | 核准/停權/指派角色 | 狀態正確變更 |
| `.../admin/posts/+page` | 內容管理 | posts | 發佈/置頂/下架 | 即時反映 |
| `.../admin/invites/+page` | 邀請碼/期別 | — | 產碼、管期別 | 碼可被註冊使用 |
| `src/lib/server/audit.ts` | 操作軌跡 | actor,action,target | 寫 `audit_logs` | 後台操作留痕 |

> **MVP 邊界＝M0–M6**：對齊 PRD MVP（F-ID-1~3、F-SH-1、F-SH-4、F-OUT-1~3）。此時系統可被搜尋、可展示、可審核、可發消息。

---

## V1 概要（MVP 後）

- **創業/產品管理**：`(app)/app/ventures` CRUD、`products` 表、ProductCard、產品 Schema。
- **內部論壇**：`(app)/app/forum`（`posts.type=thread, visibility=members`）＋ `comments`。
- **互通有無**：`(app)/app/board`（`board_items` offer/need，可標 closed）。
- **完整內部名錄**：含私密聯絡方式（僅 active 可見）。

## V2 概要

- 會員徽章嵌入碼（回鏈）、AEO/Schema 強化、檢舉處理、多期別治理、深色模式上線。

---

## 全程 watch-points（CODEX 必讀）

1. **Better Auth + D1 + Workers**：db 由 `platform.env.DB` 請求內注入；Drizzle adapter `provider:'sqlite'`；`sveltekitCookies` 置 plugins 最後。**M2 先以最小 email 登入驗通再擴 Google。**
2. **Google ≠ 繞過閘門**：新帳號預設 pending（除非邀請連結）。
3. **可見性在查詢階段過濾**，不要查出再隱藏。
4. **adapter 產出於 `.svelte-kit/cloudflare/`**，wrangler 勿指向 `dist/`。
5. **Worker 體積**：大型套件僅 client 端引入，避免超限。
