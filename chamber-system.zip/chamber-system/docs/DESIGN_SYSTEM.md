# DESIGN SYSTEM｜商會系統設計系統

| 狀態 | 版本 | 最後更新 |
|---|---|---|
| 草稿(Draft) | 0.1.0 | 待填 |

> 主題：**港都凱洛斯（Harbour Kairos）**。機構級可信度 × 社群溫度 × 決定性時刻的轉換。
> 設計北極星：每個畫面都要回答「為什麼該信任、該選擇這個人」。

---

## 1. 設計原則

1. **可信先於華麗**：主任、長官、潛在合作者都會看，視覺須穩重、不浮誇。
2. **節制的決斷色**：琥珀只用在「被選擇的瞬間」（CTA、已驗證徽章），其餘畫面安靜。
3. **結構即資訊**：分隔線、標籤、編號只在真的承載順序或分類時使用，不做裝飾。
4. **華人語境優先**：以繁體中文為第一語言設計字級與行高；不使用斜體做強調（改用字重與顏色）。

## 2. 簽名元素：信任印章（Trust Seal）

「已驗證會員」徽章做成**淡琥珀印章**意象——華人語境中，印章＝authenticity 與被背書。
- 形態：圓角方印或圓印，內含成員姓名首字或期別，邊框琥珀、底淡。
- 用途：成員頁、名錄卡、留言作者旁。是全站唯一允許「張揚」的元素，其餘保持安靜。
- 語意：未驗證者不顯示印章；印章是信任的視覺貨幣。

## 3. 色彩 Tokens

以語意命名，light 為主、dark 備用。對比一律達 WCAG AA。

| Token | Light | Dark | 用途 |
|---|---|---|---|
| `--color-ink` | `#15213A` | `#E8ECF5` | 主文字／品牌底 |
| `--color-ink-soft` | `#41506B` | `#A9B4CA` | 次要文字 |
| `--color-surface` | `#F7F8FA` | `#0E1626` | 頁面背景（冷紙，非奶油） |
| `--color-card` | `#FFFFFF` | `#16213A` | 卡片面 |
| `--color-border` | `#E2E6EE` | `#2A3550` | 分隔／框線 |
| `--color-teal` | `#1F6F6B` | `#4FB3AD` | 連結／資訊（港灣青） |
| `--color-amber` | `#D98324` | `#E8A33D` | 決斷色／CTA／印章 |
| `--color-amber-soft` | `#FBEAD3` | `#3A2C18` | 印章底／高亮背景 |
| `--color-success` | `#2E7D5B` | `#5FC79A` | 成功（媒合完成） |
| `--color-warn` | `#B06A12` | `#E0A857` | 警示（與 amber 區隔用深色調） |
| `--color-danger` | `#B23A48` | `#E2727E` | 危險／刪除 |

> 反模式：避免大面積琥珀；避免奶油底＋赤陶的 AI 預設組合。

## 4. 字體 Typography

繁體中文以 **思源黑體（Noto Sans TC）** 為內文骨幹；標題以 **思源宋體（Noto Serif TC）** 提供編輯級可信度與溫度（CJK 多數網站全用黑體，宋體標題是刻意的差異化）。拉丁字以 Inter 補強字母質感。全為開源字體，利於開源專案。

```css
--font-display: "Noto Serif TC", "Songti TC", serif;     /* 標題：宋體，可信、有溫度 */
--font-body: "Inter", "Noto Sans TC", system-ui, sans-serif; /* 內文：黑體 */
--font-mono: "IBM Plex Mono", ui-monospace, monospace;   /* 數據／標籤 */
```

**字級（CJK 需較高行高）**

| 角色 | size / line-height | 字體 |
|---|---|---|
| Display | 40–56px / 1.25 | display |
| H1 | 32px / 1.3 | display |
| H2 | 24px / 1.35 | display |
| H3 | 20px / 1.5 | body(700) |
| Body | 16px / **1.8** | body |
| Small | 14px / 1.7 | body |
| Caption/Label | 12px / 1.5 | mono |

> CJK 內文行高刻意拉到 1.8，提升中文可讀性；強調用 `font-weight: 700` 或 `--color-amber`，不用斜體。

## 5. 間距、圓角、陰影、動效

```css
/* 間距：4px 基準 */
--space-1:4px; --space-2:8px; --space-3:12px; --space-4:16px;
--space-6:24px; --space-8:32px; --space-12:48px; --space-16:64px;

/* 圓角：適度，非零角(broadsheet) 亦非全藥丸 */
--radius-sm:6px; --radius-md:12px; --radius-lg:16px; --radius-seal:8px;

/* 陰影：克制 */
--shadow-sm:0 1px 2px rgba(21,33,58,.06);
--shadow-md:0 4px 16px rgba(21,33,58,.08);

/* 動效：尊重 reduce-motion */
--ease:cubic-bezier(.2,.8,.2,1); --dur:180ms;
```

版面：12 欄網格，內容最大寬 1120px；行動裝置單欄，斷點 640 / 1024px。

## 6. 元件清單（Component Inventory）

| 元件 | 重點 |
|---|---|
| Button | primary(琥珀)、secondary(描邊)、ghost；focus 環清晰；hover 微動 |
| Input / Form field | label 在上、錯誤訊息在下；伺服器錯誤以介面語氣說明該怎麼修 |
| **MemberCard** | 頭像、姓名、產業 chip、**信任印章**、一句標語；點擊進成員頁 |
| **ProductCard** | 圖、名稱、價格標籤、外部連結箭頭（導往成員通路） |
| NewsCard | 標題(宋體)、分類、日期、摘要 |
| Nav / Header | 對外簡潔；登入後顯示「會員中心」入口 |
| **TrustSeal Badge** | 簽名元素，見 §2 |
| Industry Chip / Tag | 型錄篩選；teal 邊 |
| Tabs | 個人中心分頁 |
| Modal | 審核、刪除確認 |
| Table | 後台名錄／審核佇列 |
| Pagination | 名錄／論壇 |
| EmptyState | 空畫面是行動邀請：說明可以做什麼，附 CTA |
| Toast | 動作回饋；發佈→「已發佈」用語一致 |

## 7. 文案語氣（UX Writing）

- 用使用者控制的詞，不用系統實作詞（「管理通知」非「設定 webhook」）。
- 按鈕說清楚會發生什麼：「儲存變更」「發佈」「送出申請」；同一動作全程同名。
- 錯誤不道歉、不含糊：說明發生什麼、如何修復，用介面口吻。
- 空畫面是邀請：「還沒有產品。新增第一個，讓人看見你的服務。」

## 8. 可及性與深色模式

- 對比達 WCAG AA；所有互動元件有可見鍵盤 focus 環。
- `prefers-reduced-motion` 時關閉非必要動畫。
- 深色模式以 `[data-theme="dark"]` 切換 tokens；色彩表已備 dark 值。
- 表單錯誤不只靠顏色，附文字與圖示。

## 9. 實作建議（給 CODEX）

- **tokens 是單一事實來源**：以 CSS 自訂屬性定義於 `:root` 與 `[data-theme="dark"]`，所有元件只引用變數，不寫死色值。
- 可搭配 Tailwind v4（將 token 映射到 theme）或純 CSS；無論何者，色彩／字體一律來自上述變數。
- 元件以 Svelte 元件封裝，props 驅動狀態；避免 CSS 選擇器特異性互相抵銷（注意 section 與元素級 padding 衝突）。
- 字體以 self-host 或 Google Fonts 載入 Noto Serif/Sans TC；注意 CJK 字檔大，依語系子集化。
